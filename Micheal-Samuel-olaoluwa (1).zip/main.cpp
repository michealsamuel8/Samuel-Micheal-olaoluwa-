#include <iostream>

int main() {
    int a = 5;
    int b = 6;
    int c = a+b;
    std::cout << "Sum = " << c << std::ends;
    return 0;
}